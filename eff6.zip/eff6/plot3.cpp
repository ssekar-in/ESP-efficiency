// for plotting
#include "matplotlibcpp.h"
#include "esp_eff5.h"
#include <vector>
#include "plot3.h"

namespace plt = matplotlibcpp;

namespace plot{

void plot2(){
  plt::plot(flow1, eff1);
  plt::show();
  plt::plot(wk2, eff2);
  plt::show();
  return ;
}

}
