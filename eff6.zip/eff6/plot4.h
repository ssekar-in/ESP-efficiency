// plot4.h
//
#ifndef PLOT4_H
#define PLOT4_H

namespace plot1{

void plot2();

}

#endif
