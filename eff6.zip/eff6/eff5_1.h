// eff5_1.h

#ifndef EFF5_1_H
#define EFF5_1_H

struct esp_in {
    float height = 15;
    float length = 3.6;
    int ducts = 12;
    int pl_path = 4;
    int sr_fld = 6;
    float duct_width = .4;
    float wk = 0.24;
    float flow = 360;
};

extern struct esp_in esp_data2;
float esp_efficiency();


#endif

