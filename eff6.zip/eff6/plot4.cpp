// for plotting
#include "matplotlibcpp.h"
#include "esp_eff5.h"
#include <vector>
#include "plot4.h"


namespace plt = matplotlibcpp;

namespace plot1{

void plot2(){
  plt::plot(sr_fld1, eff3);
  plt::xlabel("Series fields");
  plt::ylabel("Efficiency %");
  //std::vector<double>xx{5,6,7,8};
  //plt::xticks(xx);
  plt::xticks(sr_fld1);
  plt::show();
  
  return ;
}

}
