// esp_eff5.h

#ifndef ESP_EFF5_H
#define ESP_EFF5_H
#include <vector>
using namespace std;

    
  extern std::vector<double>flow1;
  extern std::vector<double>eff1;
  extern std::vector<double>wk2;
  extern std::vector<double>eff2;
  extern std::vector<double>eff3;
  extern std::vector<double>sr_fld1;


 

#endif