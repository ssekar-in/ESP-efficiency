//eff5_1.cpp

#include "eff5_1.h"
#include <cmath>
#include <iostream>
#include <cstdio>
#include <vector>

esp_in esp_data2;

float esp_efficiency(){
    //struct esp_in esp_data1;
    float fld_area = 2 * esp_data2.ducts * esp_data2.height * esp_data2.length;
    float tca = esp_data2.sr_fld * esp_data2.pl_path * fld_area;
    float sca = tca/esp_data2.flow;
    float efficiency = 1 - exp(-sqrt(esp_data2.wk * sca));
    printf("  %1.4f\n", efficiency);
    return efficiency;
} 
