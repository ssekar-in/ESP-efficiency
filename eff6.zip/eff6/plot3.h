// plot3.h
//
#ifndef PLOT3_H
#define PLOT3_H

namespace plot{

void plot2();

}

#endif
