// esp_eff.cpp for calc esp eff
// compile instruction:
//g++ esp_eff3.cpp -std=c++11 -I /usr/include/python3.7m -I /home/sekar/.local/lib/python3.7m/site-packages/numpy/core/include  -lpython3.7m  -lpthread -o esp_eff3
// matplotlibcpp.h is required to be placed in the working folder. Python3-dev packae shoould have been installed. These enable graph. If you are not bothered about the graph, comment lines 6,7, 54, 55 You can print/write to file, the vectors flow1 and eff1 and plot them elsewhere
//In that case, normal compilation is good enough. no additional includes and linking to python is required, as above.
#include "plot3.h"
#include "plot4.h"
#include "eff5_1.h"
#include <cmath>
#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;
std::vector<double>flow1{};
std::vector<double>eff1{};
std::vector<double>wk2{};
std::vector<double>eff2{};
std::vector<double>eff3{};
std::vector<double>sr_fld1{};



int main(){
    
      for (int flow = 200; flow <= 450; flow = flow +10){
        esp_data2.flow = flow;
        flow1.insert(flow1.end(), flow);
        printf("%5.1f", esp_data2.flow);
        float eff = esp_efficiency();
        eff1.insert(eff1.end(), eff);
      }
    
    

      for (float wk1= .2; wk1 <= .28; wk1 = wk1+.005){
        esp_data2.flow = 360;
        esp_data2.wk = wk1;
        wk2.insert(wk2.end(), wk1);
        printf("%5.3f", esp_data2.wk);
        float eff = esp_efficiency();
        eff2.insert(eff2.end(), eff);
      }

      for (int fld = 5; fld <= 8; fld = fld+1){
        esp_data2.flow = 360;
        esp_data2.sr_fld = fld;
        sr_fld1.insert(sr_fld1.end(), fld);
        printf("%1d", esp_data2.sr_fld);
        float eff = esp_efficiency();
        eff3.insert(eff3.end(), eff);
      }

  plot::plot2();
  plot1::plot2();
   
  return 0;

}
